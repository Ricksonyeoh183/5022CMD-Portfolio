"""
5022CMD Advanced Algorithms - Question 1
Hash table (open addressing, linear probing) for a pharmacy inventory
"""

import time
import random


# ---------------------------------------------------------------------------
# Entity class: one pharmacy product
# ---------------------------------------------------------------------------
class Product:
    def __init__(self, product_id, product_name, product_price, product_stock):
        self.product_id = product_id           # whole number, used as the hash key
        self.product_name = product_name       # text
        self.product_price = product_price     # decimal number (RM)
        self.product_stock = product_stock     # whole number

    def show(self):
        print(f"ID: {self.product_id} | Name: {self.product_name} | "
              f"Price: RM{self.product_price:.2f} | Stock: {self.product_stock}")


# ---------------------------------------------------------------------------
# Hash table: each slot holds either None (empty) or one Product
# ---------------------------------------------------------------------------
class HashTable:
    def __init__(self, size):
        self.size = size
        self.slots = [None] * size   # every slot starts empty
        self.count = 0               # how many products are stored

    def hash_function(self, product_id):
        return product_id % self.size

    def insert(self, product):
        """Store the product and return its slot number (-1 if table is full)."""
        if self.count == self.size:
            return -1

        index = self.hash_function(product.product_id)

        # Linear probing: if the slot is taken, try the next one.
        # The % wraps back to slot 0 after the last slot.
        while self.slots[index] is not None:
            index = (index + 1) % self.size

        self.slots[index] = product
        self.count = self.count + 1
        return index

    def search(self, product_id):
        """Return the product with this ID, or None if it is not there."""
        index = self.hash_function(product_id)

        # An empty slot means the product cannot be further along.
        # (steps stops us looping forever on a completely full table)
        steps = 0
        while self.slots[index] is not None and steps < self.size:
            if self.slots[index].product_id == product_id:
                return self.slots[index]
            index = (index + 1) % self.size
            steps = steps + 1

        return None


# ---------------------------------------------------------------------------
# Array search: look at every product one by one
# ---------------------------------------------------------------------------
def array_search(products, product_id):
    for product in products:
        if product.product_id == product_id:
            return product
    return None


# ---------------------------------------------------------------------------
# Performance experiment: 1000 products, search each target 1000 times
# ---------------------------------------------------------------------------
def run_experiment():
    total_products = 1000
    repeats = 1000

    table = HashTable(2003)
    array = []

    ids = random.sample(range(10000, 99999), total_products)
    for product_id in ids:
        product = Product(product_id, "Medicine", 10.00, 50)
        table.insert(product)
        array.append(product)

    targets = [ids[0], ids[500], ids[999]]
    labels = ["first", "middle", "last"]

    print("\nSearching a table and an array that both hold", total_products, "products")
    print("Each search is repeated", repeats, "times; the average is shown.\n")
    print(f"{'Target':<8}{'Hash Table (ns)':>18}{'Array (ns)':>14}")
    print("-" * 40)

    for i in range(3):
        start = time.perf_counter_ns()
        for _ in range(repeats):
            table.search(targets[i])
        hash_time = (time.perf_counter_ns() - start) / repeats

        start = time.perf_counter_ns()
        for _ in range(repeats):
            array_search(array, targets[i])
        array_time = (time.perf_counter_ns() - start) / repeats

        print(f"{labels[i]:<8}{hash_time:>18.0f}{array_time:>14.0f}")


# ---------------------------------------------------------------------------
# Keep asking until the user types a valid number
# ---------------------------------------------------------------------------
def ask_int(message):
    while True:
        try:
            return int(input(message))
        except ValueError:
            print("Please enter a whole number.")


def ask_float(message):
    while True:
        try:
            return float(input(message))
        except ValueError:
            print("Please enter a number, for example 5.90")


# ---------------------------------------------------------------------------
# Main menu
# ---------------------------------------------------------------------------
def main():
    table = HashTable(101)
    array = []

    # 1042, 1143 and 1244 all give slot 32 (remainder when divided by 101),
    # so the last two collide and are pushed to the next free slots.
    starting_products = [
        Product(1042, "Paracetamol 500mg", 5.90, 120),
        Product(1043, "Amoxicillin 250mg", 12.50, 60),
        Product(1044, "Ibuprofen 200mg", 7.20, 200),
        Product(1143, "Vitamin C 1000mg", 18.00, 150),
        Product(1244, "Loratadine 10mg", 11.30, 70),
    ]
    for product in starting_products:
        table.insert(product)
        array.append(product)

    while True:
        print("\n==== Pharmacy Inventory System ====")
        print("1. Insert Product")
        print("2. Search Product")
        print("3. Display All Products")
        print("4. Run Performance Experiment")
        print("5. Exit")
        choice = input("Enter choice: ")

        if choice == "1":
            product_id = ask_int("Enter Product ID: ")

            if table.search(product_id) is not None:
                print("That Product ID already exists.")
            else:
                product_name = input("Enter Product Name: ")
                product_price = ask_float("Enter Price: ")
                product_stock = ask_int("Enter Stock Quantity: ")

                product = Product(product_id, product_name, product_price, product_stock)
                slot = table.insert(product)

                if slot == -1:
                    print("The table is full.")
                else:
                    array.append(product)
                    print(f"Product inserted successfully into slot [{slot}]")

        elif choice == "2":
            product_id = ask_int("Enter Product ID to search: ")

            start = time.perf_counter_ns()
            found = table.search(product_id)
            hash_time = time.perf_counter_ns() - start

            start = time.perf_counter_ns()
            array_search(array, product_id)
            array_time = time.perf_counter_ns() - start

            if found is not None:
                print("Product Found!")
                found.show()
            else:
                print("Product not found.")
            print(f"Search completed in {hash_time} ns (Hash Table)")
            print(f"Search completed in {array_time} ns (Array)")

        elif choice == "3":
            for i in range(table.size):
                if table.slots[i] is not None:
                    print(f"[{i}] ", end="")
                    table.slots[i].show()

        elif choice == "4":
            run_experiment()

        elif choice == "5":
            print("Exiting Inventory System. Goodbye!")
            break

        else:
            print("Invalid choice. Please enter 1 to 5.")


main()