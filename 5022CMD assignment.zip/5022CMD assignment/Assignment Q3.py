"""
5022CMD Advanced Algorithms - Question 3
Fibonacci with and without multithreading
"""

import time
import threading

NUMBERS = [35, 38, 40]   # the three Fibonacci numbers to calculate
ROUNDS = 10              # how many times each experiment is repeated


# ---------------------------------------------------------------------------
# Fibonacci function (recursive)
# ---------------------------------------------------------------------------
def fibonacci(n):
    if n <= 1:                                # 1 comparison
        return n                              # 1 return
    return fibonacci(n - 1) + fibonacci(n - 2)   # 2 subtractions, 1 addition,
                                                 # 1 return, 2 recursive calls


# ---------------------------------------------------------------------------
# With multithreading: one thread for each number
# ---------------------------------------------------------------------------
def worker(n, answers, start_times, end_times):
    """Runs inside a thread: calculate Fibonacci(n) and note the times."""
    start_times.append(time.perf_counter_ns())
    answers[n] = fibonacci(n)
    end_times.append(time.perf_counter_ns())


def run_with_threads():
    answers = {}       # number -> its Fibonacci value
    start_times = []   # the time each thread started
    end_times = []     # the time each thread finished

    # create one thread for each number
    threads = []
    for n in NUMBERS:
        thread = threading.Thread(target=worker,
                                  args=(n, answers, start_times, end_times))
        threads.append(thread)

    # start all the threads
    for thread in threads:
        thread.start()

    # wait until every thread has finished
    for thread in threads:
        thread.join()

    # T = end time of the thread that finished last
    #     minus start time of the thread that started first
    total_time = max(end_times) - min(start_times)
    return answers, total_time


# ---------------------------------------------------------------------------
# Without multithreading: one calculation after another
# ---------------------------------------------------------------------------
def run_without_threads():
    answers = {}

    start = time.perf_counter_ns()
    for n in NUMBERS:
        answers[n] = fibonacci(n)
    end = time.perf_counter_ns()

    return answers, end - start


# ---------------------------------------------------------------------------
# Run one experiment for ROUNDS rounds and print the results
# ---------------------------------------------------------------------------
def run_experiment(title, run_function):
    print(f"\n=== Fibonacci Computation ({title}) ===")

    total = 0
    for round_number in range(1, ROUNDS + 1):
        answers, round_time = run_function()
        total = total + round_time

        text = ""
        for n in NUMBERS:
            text = text + f"Fib({n})={answers[n]}, "
        print(f"Round {round_number:>2}: {text}T = {round_time:,} ns")

    average = total // ROUNDS
    print(f"Average T ({title}): {average:,} ns")
    return average


def main():
    threaded_average = run_experiment("With Multithreading", run_with_threads)
    normal_average = run_experiment("Without Multithreading", run_without_threads)

    print("\n=== Comparison ===")
    print(f"With threads    : {threaded_average:,} ns")
    print(f"Without threads : {normal_average:,} ns")

    if threaded_average < normal_average:
        difference = (normal_average - threaded_average) / normal_average * 100
        print(f"Multithreading was faster by about {difference:.1f}%.")
    else:
        difference = (threaded_average - normal_average) / normal_average * 100
        print(f"Multithreading was NOT faster; it was slower by about {difference:.1f}%.")


main()