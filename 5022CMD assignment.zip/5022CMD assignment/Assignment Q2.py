"""
5022CMD Advanced Algorithms - Question 2
Generic directed graph + university course prerequisite system
"""


# ---------------------------------------------------------------------------
# Generic unweighted directed graph (no course-specific code)
# ---------------------------------------------------------------------------
class Graph:
    def __init__(self):
        self.vertices = {}   # vertex id -> any payload object
        self.outgoing = {}   # vertex id -> list of ids this vertex points to

    def addVertex(self, vertex_id, payload=None):
        if vertex_id in self.vertices:
            raise ValueError(f"Vertex {vertex_id} already exists")
        self.vertices[vertex_id] = payload
        self.outgoing[vertex_id] = []

    def addEdge(self, from_id, to_id):
        if from_id not in self.vertices or to_id not in self.vertices:
            raise KeyError("Both vertices must exist")
        if to_id in self.outgoing[from_id]:
            raise ValueError(f"Edge {from_id} -> {to_id} already exists")
        self.outgoing[from_id].append(to_id)

    def listIncomingAdjacentVertex(self, vertex_id):
        """Every vertex with an edge pointing INTO vertex_id."""
        return [v for v, targets in self.outgoing.items() if vertex_id in targets]

    def listOutgoingAdjacentVertex(self, vertex_id):
        """Every vertex that vertex_id points TO."""
        return list(self.outgoing[vertex_id])


# ---------------------------------------------------------------------------
# Course entity
# ---------------------------------------------------------------------------
class Course:
    def __init__(self, code, name, credits, level, description, lecturer):
        self.code = code
        self.name = name
        self.credits = credits
        self.level = level            # "core" or "elective"
        self.description = description
        self.lecturer = lecturer

    def __str__(self):
        return f"{self.code} - {self.name}"

    def details(self):
        return (f"Course Code  : {self.code}\n"
                f"Course Name  : {self.name}\n"
                f"Credit Hours : {self.credits}\n"
                f"Level        : {self.level.title()}\n"
                f"Lecturer     : {self.lecturer}\n"
                f"Description  : {self.description}")


# ---------------------------------------------------------------------------
# Registration system
# ---------------------------------------------------------------------------
class RegistrationSystem:
    def __init__(self):
        self.graph = Graph()
        courses = [
            Course("CS101", "Introduction to Programming", 3, "core",
                   "Fundamentals of programming with Python.", "Dr. Tan"),
            Course("CS201", "Data Structures", 4, "core",
                   "Lists, stacks, queues, trees and hash tables.", "Dr. Lim"),
            Course("CS205", "Discrete Mathematics", 3, "core",
                   "Logic, sets, relations and graphs.", "Dr. Raj"),
            Course("CS301", "Algorithms", 4, "core",
                   "Sorting, searching, graph algorithms, complexity.", "Dr. Tan"),
            Course("CS302", "Database Systems", 3, "core",
                   "Relational model, SQL and transactions.", "Ms. Wong"),
            Course("CS310", "Machine Learning", 3, "elective",
                   "Supervised and unsupervised learning.", "Dr. Kumar"),
            Course("CS320", "Web Development", 3, "elective",
                   "Client-server web applications.", "Mr. Lee"),
            Course("CS401", "Software Engineering", 3, "core",
                   "Process, requirements, design and testing.", "Dr. Raj"),
        ]
        for c in courses:
            self.graph.addVertex(c.code, c)

        # (A, B) means A is a prerequisite of B, i.e. edge A -> B
        for prereq, course in [("CS101", "CS201"), ("CS101", "CS320"),
                               ("CS201", "CS301"), ("CS205", "CS301"),
                               ("CS201", "CS302"), ("CS301", "CS310"),
                               ("CS301", "CS401"), ("CS302", "CS401")]:
            self.graph.addEdge(prereq, course)

    def ask_code(self, prompt):
        """Ask for a course code; return it, or None if it doesn't exist."""
        code = input(prompt).strip().upper()
        if code not in self.graph.vertices:
            print(f"Course '{code}' not found.")
            return None
        return code

    def course(self, code):
        return self.graph.vertices[code]

    def print_list(self, title, codes):
        print("\n" + title)
        if len(codes) == 0:
            print("  (none)")
        for c in sorted(codes):
            print(f"  - {self.course(c)}")

    # ----- mandatory features -----
    def view_all(self):
        print("\nAvailable Courses:")
        for i, code in enumerate(sorted(self.graph.vertices), 1):
            print(f"  {i}. {self.course(code)}")

    def view_details(self):
        code = self.ask_code("Enter Course Code: ")
        if code:
            print("\n" + self.course(code).details())

    def view_prerequisites(self):
        code = self.ask_code("Enter Course Code: ")
        if code:
            self.print_list(f"Prerequisites for {self.course(code)}:",
                            self.graph.listIncomingAdjacentVertex(code))

    def view_unlocked(self):
        code = self.ask_code("Enter Course Code: ")
        if code:
            self.print_list(f"Courses unlocked by {self.course(code)}:",
                            self.graph.listOutgoingAdjacentVertex(code))


# ---------------------------------------------------------------------------
# Menu
# ---------------------------------------------------------------------------
def main():
    system = RegistrationSystem()
    while True:
        print("""
==== University Course Registration System ====
1. View All Courses
2. View Course Details (all information)
3. View Prerequisites of a Course
4. View Courses Unlocked by a Course
5. Exit""")
        choice = input("Enter choice: ").strip()

        if choice == "1":
            system.view_all()
        elif choice == "2":
            system.view_details()
        elif choice == "3":
            system.view_prerequisites()
        elif choice == "4":
            system.view_unlocked()
        elif choice == "5":
            print("Exiting program. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1-5.")


if __name__ == "__main__":
    main()